<template>
  <tiempo/>
</template>

<script>
// @ is an alias to /src
import tiempo from '@/components/Tiempo.vue'

export default {
  name: 'About',
  components: {
    tiempo
  }
}
</script>
