<template>
    <hello-world/>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/Notas.vue'


export default {
  name: 'home',
  components: {
    HelloWorld
  }
}
</script>
